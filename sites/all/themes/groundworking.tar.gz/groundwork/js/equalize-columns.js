// $Id$
$(document).ready(function() {
  $('.content-inner, .sidebar').equalHeight();
});