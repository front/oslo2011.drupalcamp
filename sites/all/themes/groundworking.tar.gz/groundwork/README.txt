
  Groundwork 6.x-1.x is built and supported by http://www.perceptivity.eu courtesy of http://www.websitecrew.com

  Project page: http://drupal.org/project/groundwork
  Issue queue:  http://drupal.org/project/issues/groundwork

  Groundwork is a highly configurable theme specially made for non-developers and non-designers.
  
  The code is not meant to be altered. All configurations can be done via the theme settings page.

  
  To maximize the features of this theme, you need to install the following modules:

  http://drupal.org/project/skinr
  Just install and its ready to use, Groundwork has built-in support for the Skinr 
  module and comes pre-packaged with many useful Skinr styles.


  http://drupal.org/project/block_class
  http://drupal.org/project/blocktheme
  Optionally you can also test out Groundwork's support for Block class and Blocktheme modules. 
  Again, theres nothing more to do other than installing these module and start 
  using them, Groundwork provides native support out of the box.

