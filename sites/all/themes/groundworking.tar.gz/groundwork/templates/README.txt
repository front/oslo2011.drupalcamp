
  /templates
  
  The templates directory contains tpl (template) files.

  Drupal supports the use of "template suggestions". For example to theme the homepage
  you can use a page-front.tpl.php, or to theme all Story type nodes you can use 
  node-story.tpl.php. A template suggestions will override the core template file.

  For more information about theme templates and template suggestions:
  http://drupal.org/node/190815
  
  There is also a handy cheat-sheet:
  http://drupal.org/files/issues/Core_templates_and_suggestions.pdf
  